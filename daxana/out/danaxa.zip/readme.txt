1. start mflask.py

2. go to http://127.0.0.1:5000/

3. set some data, for instance
x:
-4., -2.85714286, -1.71428571, -0.57142857,  0.57142857,  1.71428571,  2.85714286, 4. 
y: (y = 3*np.sin(x))
2.27040749, -0.8418882,  -2.96916915, -1.62250264,  1.62250264,  2.96916915, 0.8418882, -2.27040749 
k:
1
image:
220215.jpg

4.
output is in the folder static/upload, for example 220215.jpg